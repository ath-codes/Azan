1) افتح المجلد في Android Studio (Hedgehog أو أحدث) وانتظر مزامنة Gradle.
2) شغّل على جهازك (Run) أو: Build > Build APK.
3) للأذان: ضع ملفاً باسم adhan.mp3 داخل app/src/main/res/raw/ قبل أول تثبيت
   (إن ثبّتت قبلها: احذف التطبيق وثبّته من جديد ليتغير صوت القناة).
