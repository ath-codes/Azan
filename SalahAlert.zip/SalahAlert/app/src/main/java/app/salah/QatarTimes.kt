package app.salah

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

/**
 * مواقيت الدوحة من prayers.qa: الموقع يعرض أوقاته من ملف allprayertimes.php (سنة كاملة)،
 * فنجلبه ونحفظ نسخة في الجهاز، ونطبّق نفس تعديل الموقع (+١ دقيقة للظهر والعصر والمغرب والعشاء،
 * و+١ إضافية للمغرب والعشاء في رمضان).
 */
object QatarTimes {
    private const val BASE = "https://prayers.qa/"
    private const val UA =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private val TZ: TimeZone = TimeZone.getTimeZone("Asia/Qatar")
    /** الفجر، الظهر، العصر، المغرب، العشاء — كما في صفحة الموقع */
    private val DEFAULT_IQAMA = intArrayOf(25, 20, 25, 10, 20)

    private fun keyOf(d: Date): String =
        SimpleDateFormat("dd-MM", Locale.US).apply { timeZone = TZ }.format(d)

    private fun dayStart(d: Date): Long {
        val c = Calendar.getInstance(TZ)
        c.time = d
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    /** المحفوظ: ";DD-MM:فجر,ظهر,عصر,مغرب,عشاء;..." بدقائق اليوم */
    private fun entry(data: String, key: String): IntArray? {
        val tag = ";$key:"
        val i = data.indexOf(tag)
        if (i < 0) return null
        val from = i + tag.length
        val e = data.indexOf(';', from)
        val end = if (e < 0) data.length else e
        val parts = data.substring(from, end).split(",")
        if (parts.size != 5) return null
        return try { IntArray(5) { parts[it].toInt() } } catch (e: Exception) { null }
    }

    /** 0 = مواقيت اليوم من الموقع، 2 = لا توجد بيانات لليوم (حساب تقريبي) */
    fun status(s: Settings): Int =
        if (entry(s.qaData, keyOf(Date())) != null) 0 else 2

    fun timesFor(s: Settings, date: Date): List<Date>? {
        val m = entry(s.qaData, keyOf(date)) ?: return null
        val base = dayStart(date)
        return List(5) { Date(base + m[it] * 60_000L) }
    }

    fun iqama(s: Settings): IntArray? {
        if (entry(s.qaData, keyOf(Date())) == null) return null
        val parts = s.qaIqama.split(",")
        if (parts.size == 5) {
            try { return IntArray(5) { parts[it].trim().toInt() } } catch (e: Exception) { }
        }
        return DEFAULT_IQAMA
    }

    // ---------- الجلب ----------
    private fun get(s: Settings, path: String, json: Boolean): String? {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept-Language", "ar")
            if (json) {
                c.setRequestProperty("X-Requested-With", "XMLHttpRequest")
                c.setRequestProperty("Accept", "application/json")
                c.setRequestProperty("Referer", BASE + "os.php")
            }
            val code = c.responseCode
            if (code != 200) { s.qaDbg = "رد الموقع ($path): HTTP $code"; return null }
            return String(c.inputStream.use { it.readBytes() }, Charsets.UTF_8)
        } finally {
            c.disconnect()
        }
    }

    private fun to24(i: Int, h: Int, m: Int): Int {
        if (h >= 13) return h * 60 + m           // مكتوب بنظام 24 ساعة
        val hh = when (i) {
            0 -> h % 12                           // الفجر صباحاً
            1 -> if (h in 10..12) h else h + 12   // الظهر
            else -> h % 12 + 12                   // العصر والمغرب والعشاء مساءً
        }
        return hh * 60 + m
    }

    private fun parseAll(txt: String): String? {
        val obj = JSONObject(txt.trim())
        val keyRe = Regex("\\d{2}-\\d{2}")
        val sb = StringBuilder()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (!keyRe.matches(k)) continue
            val t = obj.optJSONObject(k) ?: continue
            try {
                val am = t.optString("armonth")
                val ram = am == "رمضان" || am == "Ramadan"
                fun mn(f: String, i: Int, add: Int): Int {
                    val p = t.getString(f).trim().split(":")
                    return to24(i, p[0].trim().toInt(), p[1].trim().toInt()) + add
                }
                val extra = if (ram) 2 else 1
                val v = intArrayOf(
                    mn("fajr", 0, 0), mn("dhur", 1, 1), mn("asr", 2, 1),
                    mn("maghrib", 3, extra), mn("isha", 4, extra)
                )
                sb.append(';').append(k).append(':').append(v.joinToString(","))
            } catch (e: Exception) {
                continue
            }
        }
        return if (sb.isEmpty()) null else sb.toString()
    }

    /** يرفض البيانات إن اختلف اليوم كثيراً عن الحساب الفلكي للدوحة، حتى لا تظهر أوقات خاطئة. */
    private fun sane(data: String, now: Date): Boolean {
        val m = entry(data, keyOf(now)) ?: return false
        val ref = PrayerCalc.doha(now)
        for (i in 0..4) {
            val c = Calendar.getInstance(TZ)
            c.time = ref[i]
            val calcMin = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            if (abs(calcMin - m[i]) > 20) return false
        }
        for (i in 1..4) if (m[i] <= m[i - 1]) return false
        return true
    }

    private fun clean(html: String): String {
        val stripped = html
            .replace(Regex("(?is)<(script|style)\\b.*?</\\1>"), " ")
            .replace(Regex("(?s)<[^>]*>"), " ")
            .replace("&nbsp;", " ")
            .replace("\u00A0", " ")
            .replace(Regex("[\u200E\u200F\u202A-\u202E\u2066-\u2069]"), "")
        val sb = StringBuilder(stripped.length)
        for (ch in stripped) {
            sb.append(
                when (ch) {
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    else -> ch
                }
            )
        }
        return sb.toString().replace(Regex("\\s+"), " ")
    }

    /** مدد الانتظار حتى الإقامة مكتوبة في صفحة os.php؛ نقرؤها وإلا نستخدم القيم المعروفة. */
    private fun fetchIqama(s: Settings): String {
        val iq = DEFAULT_IQAMA.clone()
        try {
            val html = get(s, "os.php", false) ?: return iq.joinToString(",")
            val text = clean(html)
            val idx = mapOf(0 to "الفجر", 2 to "العصر", 3 to "المغرب", 4 to "العشاء")
            for ((i, n) in idx) {
                val m = Regex(n + "\\s*\\(\\s*\\+?\\s*(\\d{1,3})\\s*\\)").find(text)
                val v = m?.groupValues?.get(1)?.toIntOrNull()
                if (v != null && v in 5..60) iq[i] = v
            }
        } catch (e: Exception) { }
        return iq.joinToString(",")
    }

    /** يجلب بيانات السنة ويحفظها. يتجاوز الجلب إن كانت النسخة حديثة. يجب استدعاؤه خارج الخيط الرئيسي. */
    fun refreshBlocking(ctx: Context, maxAgeMs: Long): Boolean {
        val s = Settings(ctx)
        val now = Date()
        if (entry(s.qaData, keyOf(now)) != null && System.currentTimeMillis() - s.qaFetched < maxAgeMs) return false
        return try {
            val txt = get(s, "allprayertimes.php", true) ?: return false
            val data = try { parseAll(txt) } catch (e: Exception) { null }
            if (data == null) {
                s.qaDbg = "وصل رد الموقع بصيغة غير متوقعة (" + txt.length + " حرف):\n" + txt.take(500)
                return false
            }
            if (!sane(data, now)) {
                s.qaDbg = "قرأت البيانات لكن مواقيت اليوم بعيدة عن الحساب الفلكي أو ناقصة، فرُفضت."
                return false
            }
            s.qaIqama = fetchIqama(s)
            s.qaData = data
            s.qaFetched = System.currentTimeMillis()
            s.qaDbg = ""
            true
        } catch (e: Exception) {
            s.qaDbg = "تعذّر الاتصال: " + e.javaClass.simpleName + " " + (e.message ?: "")
            false
        }
    }

    fun refreshAsync(ctx: Context, maxAgeMs: Long, done: () -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val changed = refreshBlocking(app, maxAgeMs)
            if (changed) done()
        }.start()
    }
}
