package app.salah

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

/** مواقيت الدوحة (والإقامة) من موقع prayers.qa، مع نسخة محفوظة في الجهاز. */
object QatarTimes {
    private const val PAGE = "https://prayers.qa/os.php"
    private val TZ: TimeZone = TimeZone.getTimeZone("Asia/Qatar")
    private val names = arrayOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
    private val hijriMonths = listOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "ربيع الثاني", "جمادى الأولى",
        "جمادى الآخرة", "جمادى الثانية", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    private class Parsed(val times: IntArray, val iqama: IntArray, val hijri: String)

    fun dayKey(d: Date): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TZ }.format(d)

    private fun absolute(day: String, minuteOfDay: Int): Date {
        val p = day.split("-")
        val c = Calendar.getInstance(TZ)
        c.clear()
        c.set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt(), minuteOfDay / 60, minuteOfDay % 60, 0)
        return c.time
    }

    private fun ints(csv: String): IntArray =
        if (csv.isEmpty()) IntArray(0) else csv.split(",").map { it.trim().toInt() }.toIntArray()

    /** 0 = مواقيت اليوم من الموقع، 1 = مواقيت محفوظة من يوم سابق (مع تعديل)، 2 = لا شيء محفوظ */
    fun status(s: Settings): Int {
        if (s.qaDay.isEmpty() || ints(s.qaTimes).size != 5) return 2
        return if (s.qaDay == dayKey(Date())) 0 else 1
    }

    /** مواقيت يوم معيّن: مطابقة للموقع في يوم الجلب، وفي غيره حساب الدوحة مضافاً إليه الفرق المرصود. */
    fun timesFor(s: Settings, date: Date): List<Date>? {
        val day = s.qaDay
        val mins = ints(s.qaTimes)
        if (day.isEmpty() || mins.size != 5) return null
        return try {
            if (dayKey(date) == day) {
                mins.map { absolute(day, it) }
            } else {
                val refCalc = PrayerCalc.doha(absolute(day, 12 * 60))
                val calc = PrayerCalc.doha(date)
                List(5) { i ->
                    val raw = absolute(day, mins[i]).time - refCalc[i].time
                    val delta = Math.round(raw / 60_000.0) * 60_000L
                    Date(calc[i].time + delta)
                }
            }
        } catch (e: Exception) { null }
    }

    fun iqama(s: Settings): IntArray? {
        val q = try { ints(s.qaIqama) } catch (e: Exception) { return null }
        return if (q.size == 5 && q.any { it > 0 }) q else null
    }

    // ---------- الجلب ----------
    private fun download(s: Settings): String? {
        val c = URL(PAGE).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5000
            c.readTimeout = 6000
            c.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
            )
            c.setRequestProperty("Accept-Language", "ar")
            val code = c.responseCode
            if (code != 200) { s.qaDbg = "رد الموقع: HTTP $code"; return null }
            val bytes = c.inputStream.use { it.readBytes() }
            val utf = String(bytes, Charsets.UTF_8)
            return if (utf.contains("الفجر")) utf else String(bytes, charset("windows-1256"))
        } finally {
            c.disconnect()
        }
    }

    private fun to24(i: Int, h: Int, m: Int): Int {
        if (h >= 13) return h * 60 + m          // الموقع يكتب بنظام 24 ساعة
        val hh = when (i) {
            0 -> h % 12                          // الفجر صباحاً
            1 -> if (h in 10..12) h else h + 12  // الظهر: 10-11 صباحاً، 12 ظهراً، 1-9 مساءً
            else -> h % 12 + 12                  // العصر والمغرب والعشاء مساءً
        }
        return hh * 60 + m
    }

    private fun clean(html: String): String {
        val stripped = html
            .replace(Regex("(?is)<(script|style)\\b.*?</\\1>"), " ")
            .replace(Regex("(?s)<[^>]*>"), " ")
            .replace("&nbsp;", " ")
            .replace("\u00A0", " ")
            .replace(Regex("[\u200E\u200F\u202A-\u202E\u2066-\u2069]"), "")
        val sb = StringBuilder(stripped.length)
        for (ch in stripped) {
            sb.append(
                when (ch) {
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    else -> ch
                }
            )
        }
        return sb.toString().replace(Regex("\\s+"), " ")
    }

    private fun parse(text: String): Parsed? {
        val mins = IntArray(5)
        val iq = IntArray(5)
        for (i in 0..4) {
            val re = Regex(names[i] + "\\s*(\\d{1,2})\\s*:\\s*(\\d{2})(?:\\s*\\(\\s*\\+?\\s*(\\d{1,3})\\s*\\+?\\s*\\))?")
            val m = re.find(text) ?: return null
            mins[i] = to24(i, m.groupValues[1].toInt(), m.groupValues[2].toInt())
            iq[i] = m.groupValues[3].toIntOrNull() ?: 0
        }

        var hijri = ""
        for (mo in hijriMonths) {
            val h = Regex("(\\d{1,2})\\s+" + Regex.escape(mo)).find(text)
            val d = h?.groupValues?.get(1)?.toIntOrNull()
            if (d != null && d in 1..30) { hijri = "$d|$mo"; break }
        }
        return Parsed(mins, iq, hijri)
    }

    /** يرفض أي نتيجة تختلف كثيراً عن الحساب الفلكي للدوحة، حتى لا تظهر أوقات خاطئة. */
    private fun sane(p: Parsed, day: String): Boolean {
        val ref = PrayerCalc.doha(absolute(day, 12 * 60))
        for (i in 0..4) {
            val c = Calendar.getInstance(TZ)
            c.time = ref[i]
            val calcMin = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            if (abs(calcMin - p.times[i]) > 20) return false
        }
        for (i in 1..4) if (p.times[i] <= p.times[i - 1]) return false
        return p.iqama.all { it in 0..90 }
    }

    /** يجلب الصفحة ويحفظ النتيجة. يتجاوز الجلب إن كانت النسخة حديثة. يجب استدعاؤه خارج الخيط الرئيسي. */
    fun refreshBlocking(ctx: Context, maxAgeMs: Long): Boolean {
        val s = Settings(ctx)
        val now = Date()
        val day = dayKey(now)
        if (s.qaDay == day && System.currentTimeMillis() - s.qaFetched < maxAgeMs) return false
        return try {
            val html = download(s) ?: return false
            val text = clean(html)
            val p = parse(text)
            if (p == null) {
                s.qaDbg = "وصلت الصفحة (" + html.length + " حرف) لكني لم أجد المواقيت فيها.\n" +
                    "تحتوي كلمة الفجر: " + (if (html.contains("الفجر")) "نعم" else "لا") + "\n\n" +
                    "بداية النص:\n" + text.take(600)
                return false
            }
            if (!sane(p, day)) {
                s.qaDbg = "قرأت المواقيت لكنها بعيدة عن الحساب الفلكي فرُفضت:\n" + p.times.joinToString(" ")
                return false
            }
            s.qaDbg = ""
            s.qaTimes = p.times.joinToString(",")
            s.qaIqama = p.iqama.joinToString(",")
            s.qaHijri = p.hijri
            s.qaDay = day
            s.qaFetched = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            s.qaDbg = "تعذّر الاتصال: " + e.javaClass.simpleName + " " + (e.message ?: "")
            false
        }
    }

    fun refreshAsync(ctx: Context, maxAgeMs: Long, done: () -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val changed = refreshBlocking(app, maxAgeMs)
            if (changed) done()
        }.start()
    }
}
