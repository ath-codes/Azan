package app.salah

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Notifier.show(ctx, intent.getIntExtra("i", 0).coerceIn(0, 4))
        Scheduler.schedule(ctx, graceMillis = 30_000)
    }
}
