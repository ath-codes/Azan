package app.salah

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val st = Settings(ctx)
        if (!st.alertsOn) return
        val i = intent.getIntExtra("i", 0).coerceIn(0, 4)
        val pre = intent.getIntExtra("pre", 0)
        if (pre > 0) {
            // تذكير قبل الصلاة: إشعار هادئ فقط، والتنبيه الأصلي مجدول مسبقاً
            Notifier.remind(ctx, i, pre)
            return
        }
        Notifier.show(ctx, i)
        Scheduler.schedule(ctx, graceMillis = 30_000)
        if (st.isDoha) {
            // تحديث مواقيت قطر في الخلفية بعد الإشعار (إن مرّت ست ساعات أو تغيّر اليوم)
            val pr = goAsync()
            Thread {
                try {
                    if (QatarTimes.refreshBlocking(ctx.applicationContext, 6 * 3600_000L)) {
                        Scheduler.schedule(ctx.applicationContext, graceMillis = 30_000)
                    }
                } catch (e: Exception) {
                } finally {
                    pr.finish()
                }
            }.start()
        }
    }
}
