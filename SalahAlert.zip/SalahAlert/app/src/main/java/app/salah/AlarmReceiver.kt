package app.salah

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val i = intent.getIntExtra("i", 0).coerceIn(0, 4)
        val pre = intent.getIntExtra("pre", 0)
        if (pre > 0) {
            // تذكير قبل الصلاة: إشعار هادئ فقط، والتنبيه الأصلي مجدول مسبقاً
            Notifier.remind(ctx, i, pre)
            return
        }
        Notifier.show(ctx, i)
        Scheduler.schedule(ctx, graceMillis = 30_000)
    }
}
