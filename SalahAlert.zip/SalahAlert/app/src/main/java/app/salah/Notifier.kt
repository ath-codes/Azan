package app.salah

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build

object Notifier {
    private const val CH = "adhan_v1"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) != null) return
        // إن وضعت ملف res/raw/adhan.mp3 سيُستخدم تلقائياً كصوت للتنبيه
        val raw = ctx.resources.getIdentifier("adhan", "raw", ctx.packageName)
        val sound: Uri = if (raw != 0) Uri.parse("android.resource://${ctx.packageName}/$raw")
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val ch = NotificationChannel(CH, "أوقات الصلاة", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(
            sound,
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
        )
        nm.createNotificationChannel(ch)
    }

    fun show(ctx: Context, index: Int) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 2, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH)
        else Notification.Builder(ctx)
        val n = b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان الآن وقت صلاة ${PrayerCalc.names[index]}")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(100 + index, n)
    }
}
