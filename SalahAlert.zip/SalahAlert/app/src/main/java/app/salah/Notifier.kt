package app.salah

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build

object Notifier {
    private const val CH = "adhan_v1"

    fun soundUri(ctx: Context): Uri {
        val raw = ctx.resources.getIdentifier("adhan", "raw", ctx.packageName)
        return if (raw != 0) Uri.parse("android.resource://${ctx.packageName}/$raw")
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    private const val CH_R = "remind_v1"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            // إن وضعت ملف res/raw/adhan.mp3 سيُستخدم تلقائياً كصوت للتنبيه
            val sound = soundUri(ctx)
            val ch = NotificationChannel(CH, "أوقات الصلاة", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                sound,
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
            )
            nm.createNotificationChannel(ch)
        }
        if (nm.getNotificationChannel(CH_R) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH_R, "تذكير قبل الصلاة", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    /** تذكير هادئ قبل الصلاة بعدد من الدقائق (بصوت الإشعار الافتراضي). */
    fun remind(ctx: Context, index: Int, mins: Int) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 20 + index, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH_R)
        else Notification.Builder(ctx).setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE)
        val n = b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("بقي $mins دقيقة على صلاة ${PrayerCalc.names[index]}")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(200 + index, n)
    }

    fun show(ctx: Context, index: Int) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 10 + index,
            Intent(ctx, AlertActivity::class.java).putExtra("i", index)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH)
        else Notification.Builder(ctx)
        val n = b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان الآن وقت صلاة ${PrayerCalc.names[index]}")
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(100 + index, n)
    }
}
