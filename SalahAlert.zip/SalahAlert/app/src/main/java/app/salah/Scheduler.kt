package app.salah

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object Scheduler {
    /** يجدول تنبيه الصلاة القادمة فقط؛ وعند وقوعه يُجدول الذي بعده. */
    fun schedule(ctx: Context, graceMillis: Long = 0) {
        val (i, t) = PrayerCalc.next(Settings(ctx), System.currentTimeMillis() + graceMillis)
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            ctx, 0, Intent(ctx, AlarmReceiver::class.java).putExtra("i", i),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.time, pi)
        } else {
            val show = PendingIntent.getActivity(
                ctx, 1, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            am.setAlarmClock(AlarmManager.AlarmClockInfo(t.time, show), pi)
        }
    }
}
