package app.salah

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object Scheduler {
    /** يجدول تنبيه الصلاة القادمة (وتذكيرها المسبق إن فُعّل)؛ وعند وقوعه يُجدول الذي بعده. */
    fun schedule(ctx: Context, graceMillis: Long = 0) {
        val st = Settings(ctx)
        val (i, t) = PrayerCalc.next(st, System.currentTimeMillis() + graceMillis)
        val am = ctx.getSystemService(AlarmManager::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        val pi = PendingIntent.getBroadcast(
            ctx, 0, Intent(ctx, AlarmReceiver::class.java).putExtra("i", i), flags
        )
        setAt(ctx, am, t.time, pi)

        // التذكير المسبق (طلب منفصل برقم 3)
        val pre = st.remind
        val rpi = PendingIntent.getBroadcast(
            ctx, 3, Intent(ctx, AlarmReceiver::class.java).putExtra("i", i).putExtra("pre", pre), flags
        )
        am.cancel(rpi)
        val rt = t.time - pre * 60_000L
        if (pre > 0 && rt > System.currentTimeMillis() + 5_000) setAt(ctx, am, rt, rpi)
    }

    private fun setAt(ctx: Context, am: AlarmManager, at: Long, pi: PendingIntent) {
        val show = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                return
            }
        } catch (e: SecurityException) { }
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}
