package app.salah

import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import java.util.Calendar
import java.util.Date

object PrayerCalc {
    val names = arrayOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

    val methodNames = listOf(
        "أم القرى", "رابطة العالم الإسلامي", "الهيئة المصرية", "كراتشي",
        "أمريكا الشمالية", "الكويت", "قطر", "دبي"
    )
    private val methods = arrayOf(
        CalculationMethod.UMM_AL_QURA, CalculationMethod.MUSLIM_WORLD_LEAGUE,
        CalculationMethod.EGYPTIAN, CalculationMethod.KARACHI,
        CalculationMethod.NORTH_AMERICA, CalculationMethod.KUWAIT,
        CalculationMethod.QATAR, CalculationMethod.DUBAI
    )

    class City(val name: String, val lat: Double, val lon: Double)
    val cities = listOf(
        City("مكة المكرمة", 21.4225, 39.8262), City("المدينة المنورة", 24.4672, 39.6111),
        City("الرياض", 24.7136, 46.6753), City("جدة", 21.5433, 39.1728),
        City("الدمام", 26.4207, 50.0888), City("القاهرة", 30.0444, 31.2357),
        City("الإسكندرية", 31.2001, 29.9187), City("الخرطوم", 15.5007, 32.5599),
        City("دمشق", 33.5138, 36.2765), City("بغداد", 33.3152, 44.3661),
        City("عمّان", 31.9454, 35.9284), City("بيروت", 33.8938, 35.5018),
        City("القدس", 31.7683, 35.2137), City("الكويت", 29.3759, 47.9774),
        City("الدوحة", 25.2854, 51.5310), City("المنامة", 26.2285, 50.5860),
        City("دبي", 25.2048, 55.2708), City("أبوظبي", 24.4539, 54.3773),
        City("مسقط", 23.5880, 58.3829), City("صنعاء", 15.3694, 44.1910),
        City("طرابلس", 32.8872, 13.1913), City("تونس", 36.8065, 10.1815),
        City("الجزائر", 36.7538, 3.0588), City("الرباط", 34.0209, -6.8416),
        City("الدار البيضاء", 33.5731, -7.5898), City("إسطنبول", 41.0082, 28.9784)
    )

    fun times(s: Settings, date: Date): List<Date> {
        val params = methods[s.method].parameters
        if (s.hanafi) params.madhab = Madhab.HANAFI
        val t = PrayerTimes(Coordinates(s.lat, s.lon), DateComponents.from(date), params)
        return listOf(t.fajr, t.dhuhr, t.asr, t.maghrib, t.isha)
    }

    /** أقرب صلاة بعد الوقت المعطى (اليوم أو فجر الغد). */
    fun next(s: Settings, afterMillis: Long): Pair<Int, Date> {
        val cal = Calendar.getInstance()
        for (d in 0..2) {
            val t = times(s, cal.time)
            for (i in t.indices) if (t[i].time > afterMillis) return i to t[i]
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return 0 to Date(afterMillis + 3600_000)
    }
}
