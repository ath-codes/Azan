package app.salah

import android.app.Activity
import android.app.NotificationManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** شاشة كبيرة تظهر وقت الصلاة (حتى مع قفل الشاشة). */
class AlertActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var idx = 0

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val green = Color.parseColor("#0B5D3B")
        val gold = Color.parseColor("#FFD966")
        window.statusBarColor = green

        val i = intent.getIntExtra("i", 0).coerceIn(0, 4)
        idx = i
        val dp = resources.displayMetrics.density

        fun tv(size: Float, color: Int) = TextView(this).apply {
            textSize = size; setTextColor(color); gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(green)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding((24 * dp).toInt(), (24 * dp).toInt(), (24 * dp).toInt(), (24 * dp).toInt())
        }
        root.addView(tv(32f, Color.WHITE).apply { text = "حان الآن وقت صلاة" })
        root.addView(tv(76f, gold).apply { text = PrayerCalc.names[i] },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = (12 * dp).toInt(); bottomMargin = (48 * dp).toInt() })

        val btn = Button(this).apply {
            text = "إيقاف الصوت"
            textSize = 30f
            isAllCaps = false
            setTypeface(null, Typeface.BOLD)
            setTextColor(green)
            background = GradientDrawable().apply {
                setColor(gold); cornerRadius = 24 * dp
            }
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                getSystemService(NotificationManager::class.java).cancel(100 + i)
                finish()
            }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, (96 * dp).toInt()))
        root.addView(
            tv(18f, Color.parseColor("#CFE8DA")).apply { text = "تُغلق هذه الشاشة تلقائياً بعد دقيقة" },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = (20 * dp).toInt() }
        )
        setContentView(root)

        // تُغلق الشاشة وحدها بعد دقيقة، فيعود الهاتف لإطفاء الشاشة بشكل طبيعي
        handler.postDelayed({
            getSystemService(NotificationManager::class.java).cancel(100 + idx)
            finish()
        }, 60_000)
    }
}
