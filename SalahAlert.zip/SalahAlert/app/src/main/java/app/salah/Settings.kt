package app.salah

import android.content.Context

class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
    var lat: Double
        get() = sp.getString("lat", "21.4225")!!.toDouble()
        set(v) { sp.edit().putString("lat", v.toString()).apply() }
    var lon: Double
        get() = sp.getString("lon", "39.8262")!!.toDouble()
        set(v) { sp.edit().putString("lon", v.toString()).apply() }
    var city: Int
        get() = sp.getInt("city", 1)
        set(v) { sp.edit().putInt("city", v).apply() }
    var method: Int
        get() = sp.getInt("method", 0)
        set(v) { sp.edit().putInt("method", v).apply() }
    var hanafi: Boolean
        get() = sp.getBoolean("hanafi", false)
        set(v) { sp.edit().putBoolean("hanafi", v).apply() }
    /** دقائق التذكير قبل الصلاة (0 = بدون تذكير) */
    var remind: Int
        get() = sp.getInt("remind", 0)
        set(v) { sp.edit().putInt("remind", v).apply() }
    /** 0 = فاتح (الافتراضي)، 1 = داكن، 2 = حسب النظام */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    /** تفعيل صوت الأذان وقت الصلاة (إن عُطّل يصل إشعار صامت) */
    var soundOn: Boolean
        get() = sp.getBoolean("soundOn", true)
        set(v) { sp.edit().putBoolean("soundOn", v).apply() }
}
