package app.salah

import android.content.Context

class Settings(ctx: Context) {
    companion object {
        /** رقم الدوحة في قائمة المدن (0 = الموقع الحالي، ثم المدن بالترتيب) */
        const val DOHA = 15
    }

    private val sp = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)

    init {
        // مرة واحدة فقط: تصبح الدوحة هي الوضع الافتراضي (حتى بعد التحديث من نسخة قديمة)
        if (!sp.getBoolean("doha_v1", false)) {
            sp.edit()
                .putInt("city", DOHA)
                .putString("lat", "25.2854")
                .putString("lon", "51.5310")
                .putInt("method", 6)
                .putBoolean("doha_v1", true)
                .apply()
        }
    }

    var lat: Double
        get() = sp.getString("lat", "25.2854")!!.toDouble()
        set(v) { sp.edit().putString("lat", v.toString()).apply() }
    var lon: Double
        get() = sp.getString("lon", "51.5310")!!.toDouble()
        set(v) { sp.edit().putString("lon", v.toString()).apply() }
    var city: Int
        get() = sp.getInt("city", DOHA)
        set(v) { sp.edit().putInt("city", v).apply() }
    val isDoha: Boolean get() = city == DOHA
    var method: Int
        get() = sp.getInt("method", 6)
        set(v) { sp.edit().putInt("method", v).apply() }
    var hanafi: Boolean
        get() = sp.getBoolean("hanafi", false)
        set(v) { sp.edit().putBoolean("hanafi", v).apply() }
    /** دقائق التذكير قبل الصلاة (0 = بدون تذكير) */
    var remind: Int
        get() = sp.getInt("remind", 0)
        set(v) { sp.edit().putInt("remind", v).apply() }
    /** 0 = فاتح (الافتراضي)، 1 = داكن، 2 = حسب النظام */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    /** تفعيل صوت الأذان وقت الصلاة (إن عُطّل يصل إشعار صامت) */
    var soundOn: Boolean
        get() = sp.getBoolean("soundOn", true)
        set(v) { sp.edit().putBoolean("soundOn", v).apply() }
    /** المفتاح العام: إن كان false تتوقف جميع التنبيهات (الأذان والتذكير) */
    var alertsOn: Boolean
        get() = sp.getBoolean("alertsOn", true)
        set(v) { sp.edit().putBoolean("alertsOn", v).apply() }
    /** أكّد المستخدم أنه فعّل استثناء البطارية (للهواتف التي لا تُظهر الحالة بدقة) */
    var batteryAck: Boolean
        get() = sp.getBoolean("batteryAck", false)
        set(v) { sp.edit().putBoolean("batteryAck", v).apply() }

    // ---- نسخة محفوظة من مواقيت قطر (prayers.qa) ----
    /** تاريخ اليوم (بتوقيت قطر) الذي تخصه المواقيت المحفوظة yyyy-MM-dd */
    var qaDay: String
        get() = sp.getString("qa_day", "")!!
        set(v) { sp.edit().putString("qa_day", v).apply() }
    /** دقائق اليوم للصلوات الخمس مفصولة بفواصل */
    var qaTimes: String
        get() = sp.getString("qa_times", "")!!
        set(v) { sp.edit().putString("qa_times", v).apply() }
    /** دقائق الانتظار حتى الإقامة للصلوات الخمس */
    var qaIqama: String
        get() = sp.getString("qa_iqama", "")!!
        set(v) { sp.edit().putString("qa_iqama", v).apply() }
    /** التاريخ الهجري كما في الموقع: "28|جمادى الأولى" */
    var qaHijri: String
        get() = sp.getString("qa_hijri", "")!!
        set(v) { sp.edit().putString("qa_hijri", v).apply() }
    /** سبب آخر فشل في قراءة prayers.qa (للتشخيص) */
    var qaDbg: String
        get() = sp.getString("qa_dbg", "")!!
        set(v) { sp.edit().putString("qa_dbg", v).apply() }
    var qaFetched: Long
        get() = sp.getLong("qa_fetched", 0L)
        set(v) { sp.edit().putLong("qa_fetched", v).apply() }
}
