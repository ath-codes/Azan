package app.salah

import android.content.Context

class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
    var lat: Double
        get() = sp.getString("lat", "21.4225")!!.toDouble()
        set(v) { sp.edit().putString("lat", v.toString()).apply() }
    var lon: Double
        get() = sp.getString("lon", "39.8262")!!.toDouble()
        set(v) { sp.edit().putString("lon", v.toString()).apply() }
    var city: Int
        get() = sp.getInt("city", 1)
        set(v) { sp.edit().putInt("city", v).apply() }
    var method: Int
        get() = sp.getInt("method", 0)
        set(v) { sp.edit().putInt("method", v).apply() }
    var hanafi: Boolean
        get() = sp.getBoolean("hanafi", false)
        set(v) { sp.edit().putBoolean("hanafi", v).apply() }
}
