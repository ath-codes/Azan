package app.salah

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings as AndroidSettings
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var s: Settings
    private var dlg: AlertDialog? = null
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("hh:mm a", Locale("ar"))
    private val nf = NumberFormat.getInstance(Locale("ar"))

    // ألوان ثابتة
    private val GREEN = Color.parseColor("#0B5D3B")
    private val GOLD = Color.parseColor("#FFD966")

    // ألوان تتغير حسب المظهر (فاتح / داكن)
    private var isDark = false
    private var BG = 0
    private var CARD = 0
    private var CARD_STROKE = 0
    private var TXT = 0
    private var MUTED = 0
    private var ACCENT = 0
    private var HI_FILL = 0
    private var HI_STROKE = 0
    private var HI_TXT = 0
    private var CHIP = 0
    private var DLG_BG = 0
    private var SEL_BG = 0

    private var ringtone: Ringtone? = null
    private lateinit var dayTv: TextView
    private lateinit var gregTop: TextView
    private lateinit var gregBot: TextView
    private lateinit var hijriTop: TextView
    private lateinit var hijriBot: TextView
    private lateinit var headLbl: TextView
    private lateinit var cityTv: TextView
    private lateinit var nextName: TextView
    private lateinit var nextTime: TextView
    private lateinit var remainTv: TextView
    private val rowBox = arrayOfNulls<LinearLayout>(5)
    private val rowName = arrayOfNulls<TextView>(5)
    private val rowTime = arrayOfNulls<TextView>(5)

    private val tick = object : Runnable {
        override fun run() {
            refresh(false)
            handler.postDelayed(this, 30_000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, stroke: Int = 0, radius: Int = 20) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(3), stroke)
    }

    private fun tv(size: Float, color: Int, bold: Boolean = true, g: Int = Gravity.CENTER) =
        TextView(this).apply {
            textSize = size
            setTextColor(color)
            gravity = g
            includeFontPadding = false
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun tap(v: View) { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    private fun loadPalette() {
        isDark = when (s.theme) {
            1 -> true
            2 -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
            else -> false
        }
        if (isDark) {
            BG = Color.parseColor("#0F1713")
            CARD = Color.parseColor("#1C2822")
            CARD_STROKE = Color.parseColor("#36483F")
            TXT = Color.parseColor("#F2EFE4")
            MUTED = Color.parseColor("#B9B7A8")
            ACCENT = Color.parseColor("#7FD1A4")
            HI_FILL = Color.parseColor("#3D3412")
            HI_STROKE = Color.parseColor("#E0B22E")
            HI_TXT = Color.parseColor("#FFE9A8")
            CHIP = Color.parseColor("#26332D")
            DLG_BG = Color.parseColor("#1C2822")
            SEL_BG = Color.parseColor("#2C3A33")
        } else {
            BG = Color.parseColor("#F7F3E8")
            CARD = Color.WHITE
            CARD_STROKE = Color.parseColor("#C9C3B0")
            TXT = Color.parseColor("#1B1B1B")
            MUTED = Color.parseColor("#4A4A3C")
            ACCENT = GREEN
            HI_FILL = Color.parseColor("#FFEFB8")
            HI_STROKE = Color.parseColor("#D4A017")
            HI_TXT = Color.parseColor("#1B1B1B")
            CHIP = Color.parseColor("#E9E2CC")
            DLG_BG = Color.WHITE
            SEL_BG = Color.parseColor("#E9E2CC")
        }
        window.statusBarColor = if (isDark) Color.parseColor("#0A110E") else GREEN
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        s = Settings(this)
        Notifier.ensureChannel(this)
        loadPalette()
        setContentView(buildUi())

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        refresh(true)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }

        // شريط التاريخ: ميلادي يميناً، اليوم في الوسط، هجري يساراً
        fun sideCol(top: TextView, bot: TextView) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(top, LinearLayout.LayoutParams(-1, -2))
            addView(bot, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        }
        gregTop = tv(18f, TXT, true).apply {
            maxLines = 1
            if (Build.VERSION.SDK_INT >= 26) setAutoSizeTextTypeUniformWithConfiguration(12, 18, 1, TypedValue.COMPLEX_UNIT_SP)
        }
        gregBot = tv(16f, MUTED, false)
        hijriTop = tv(18f, TXT, true).apply {
            maxLines = 1
            if (Build.VERSION.SDK_INT >= 26) setAutoSizeTextTypeUniformWithConfiguration(12, 18, 1, TypedValue.COMPLEX_UNIT_SP)
        }
        hijriBot = tv(16f, MUTED, false)
        dayTv = tv(26f, ACCENT, true).apply {
            typeface = Typeface.create("serif", Typeface.BOLD)
            background = shape(CHIP, 0, 16)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        val dateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, dp(10))
            addView(sideCol(gregTop, gregBot), LinearLayout.LayoutParams(0, -2, 1f))
            addView(dayTv, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(6); marginEnd = dp(6) })
            addView(sideCol(hijriTop, hijriBot), LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(dateRow, LinearLayout.LayoutParams(-1, -2))

        // البطاقة العليا (الصلاة القادمة أو الحالية)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = shape(GREEN, 0, 28)
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        headLbl = tv(22f, Color.WHITE, false)
        nextName = tv(50f, GOLD)
        nextTime = tv(42f, Color.WHITE)
        remainTv = tv(24f, Color.WHITE)
        cityTv = tv(18f, Color.parseColor("#CFE8DA"), false)
        for (v in listOf(headLbl, nextName, nextTime, remainTv, cityTv)) head.addView(v)
        root.addView(head, LinearLayout.LayoutParams(-1, -2))

        // الصلوات الخمس
        for (i in 0..4) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(24), 0, dp(24), 0)
            }
            val n = tv(28f, TXT, true, Gravity.START or Gravity.CENTER_VERTICAL)
            val t = tv(28f, TXT, true, Gravity.END or Gravity.CENTER_VERTICAL)
            row.addView(n, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(t, LinearLayout.LayoutParams(-2, -2))
            rowBox[i] = row; rowName[i] = n; rowTime[i] = t
            root.addView(row, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        }

        // زر الإعدادات
        val btn = Button(this).apply {
            text = "الإعدادات"
            textSize = 26f
            isAllCaps = false
            setTypeface(null, Typeface.BOLD)
            setTextColor(ACCENT)
            background = shape(CARD, ACCENT, 20)
            setOnClickListener { tap(it); openSettings(true) }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, 0, 1.1f).apply { topMargin = dp(12) })
        return root
    }

    override fun onResume() {
        super.onResume()
        // بعد العودة من إعدادات الهاتف ننتظر لحظة ليسجّل النظام الإذن قبل الفحص
        handler.postDelayed({ checkBattery() }, if (batteryTried) 900L else 0L)
        refresh(true)
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 30_000)
    }

    override fun onPause() {
        super.onPause()
        stopSound()
        handler.removeCallbacks(tick)
    }

    private fun updateDates(d: Date) {
        val ar = Locale("ar")
        dayTv.text = SimpleDateFormat("EEEE", ar).format(d)
        gregTop.text = SimpleDateFormat("d MMMM", ar).format(d)
        gregBot.text = SimpleDateFormat("yyyy", ar).format(d) + " م"
        try {
            val u = android.icu.util.ULocale("ar@calendar=islamic-umalqura")
            hijriTop.text = android.icu.text.SimpleDateFormat("d MMMM", u).format(d)
            hijriBot.text = android.icu.text.SimpleDateFormat("y", u).format(d) + " هـ"
        } catch (e: Exception) {
            hijriTop.text = ""; hijriBot.text = ""
        }
    }

    private fun cityName() =
        if (s.city == 0) "موقعي الحالي" else PrayerCalc.cities[s.city - 1].name

    private fun durText(mins: Int): String {
        val h = mins / 60
        val m = mins % 60
        return when {
            h == 0 -> "${nf.format(m)} دقيقة"
            m == 0 -> "${nf.format(h)} ساعة"
            else -> "${nf.format(h)} ساعة و ${nf.format(m)} دقيقة"
        }
    }

    private fun remainText(mins: Int) =
        if (mins < 1) "بعد أقل من دقيقة" else "بعد " + durText(mins)

    private fun agoText(mins: Int) =
        if (mins < 1) "الآن" else "منذ " + durText(mins)

    private fun refresh(schedule: Boolean) {
        val now = Date()
        val nowMs = now.time
        val times = PrayerCalc.times(s, now)
        val cur = PrayerCalc.current(s, nowMs)          // صلاة دخل وقتها قبل أقل من 30 دقيقة
        val (ni, nt) = PrayerCalc.next(s, nowMs)
        val focus = cur ?: (ni to nt)

        if (cur != null) {
            headLbl.text = "حان الآن وقت صلاة"
            remainTv.text = agoText(((nowMs - cur.second.time) / 60_000).toInt())
        } else {
            headLbl.text = "الصلاة القادمة"
            remainTv.text = remainText(((nt.time - nowMs + 59_999) / 60_000).toInt())
        }
        nextName.text = PrayerCalc.names[focus.first]
        nextTime.text = fmt.format(focus.second)
        cityTv.text = "المدينة: ${cityName()}"
        updateDates(now)
        for (i in 0..4) {
            val on = i == focus.first
            rowName[i]!!.text = PrayerCalc.names[i]
            rowTime[i]!!.text = fmt.format(if (on) focus.second else times[i])
            val fg = if (on) HI_TXT else TXT
            rowName[i]!!.setTextColor(fg)
            rowTime[i]!!.setTextColor(fg)
            rowBox[i]!!.background =
                if (on) shape(HI_FILL, HI_STROKE, 18) else shape(CARD, CARD_STROKE, 18)
        }
        if (schedule) Scheduler.schedule(this)
    }

    // ---------- الإعدادات (نافذة واحدة يتبدّل محتواها دون إغلاق) ----------
    private var sDlg: AlertDialog? = null
    private var sBody: LinearLayout? = null
    private var sTitle: TextView? = null
    private var sMsg: TextView? = null
    private var sList: ListView? = null
    private var sHome: ScrollView? = null
    private var sHomeBox: LinearLayout? = null
    private var sBtn: Button? = null

    /** خلفية بطاقة: عادية أو مختارة، مع لون عند الضغط */
    private fun cardBg(selected: Boolean) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), shape(HI_FILL, HI_STROKE, 16))
        addState(intArrayOf(), shape(CARD, if (selected) ACCENT else CARD_STROKE, 16))
    }

    private fun ensureDialog() {
        if (sDlg?.isShowing == true) return
        val title = tv(26f, Color.WHITE, true).apply { setPadding(dp(20), dp(16), dp(20), dp(16)) }
        val msg = tv(20f, TXT, false, Gravity.START or Gravity.CENTER_VERTICAL).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(22), dp(12), dp(22), dp(2))
            visibility = View.GONE
        }
        val lv = ListView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            selector = ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(14), dp(10), dp(14), dp(6))
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val homeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(4), dp(14), dp(10))
        }
        val home = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(homeBox)
            visibility = View.GONE
        }
        val btn = Button(this).apply {
            textSize = 24f
            isAllCaps = false
            setTypeface(null, Typeface.BOLD)
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(title, LinearLayout.LayoutParams(-1, -2))
            addView(msg, LinearLayout.LayoutParams(-1, -2))
            addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(home, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(btn, LinearLayout.LayoutParams(-1, dp(60)).apply {
                setMargins(dp(14), dp(4), dp(14), dp(14))
            })
        }
        sTitle = title; sMsg = msg; sList = lv; sHome = home; sHomeBox = homeBox; sBtn = btn; sBody = body
        val d = AlertDialog.Builder(this).setView(body).create()
        d.setOnDismissListener { stopSound(); sDlg = null }
        d.show()
        d.window?.apply {
            // ارتفاع ثابت لكل الصفحات حتى لا تقفز النافذة عند التنقل
            val dm = resources.displayMetrics
            setLayout((dm.widthPixels * 0.92f).toInt(), (dm.heightPixels * 0.72f).toInt())
        }
        sDlg = d
    }

    /** الإطار المشترك: خلفية النافذة، شريط العنوان الأخضر، زر الرجوع، وانتقال ناعم */
    private fun chrome(title: String, backLabel: String, forward: Boolean, animate: Boolean, onBack: () -> Unit) {
        sDlg?.window?.setBackgroundDrawable(shape(BG, 0, 24))
        val r = dp(24).toFloat()
        sTitle!!.apply {
            text = title
            background = GradientDrawable().apply {
                setColor(GREEN)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }
        sBtn!!.apply {
            text = backLabel
            setTextColor(ACCENT)
            background = shape(CARD, ACCENT, 18)
            setOnClickListener { tap(it); onBack() }
        }
        if (animate) {
            val body = sBody!!
            body.animate().cancel()
            body.alpha = 0f
            body.translationX = dp(if (forward) -28 else 28).toFloat()
            body.animate().alpha(1f).translationX(0f).setDuration(160).start()
        }
    }

    private fun showPage(
        title: String, items: List<String>, selected: Int, backLabel: String,
        forward: Boolean, message: String? = null, animate: Boolean = true,
        onBack: () -> Unit, onPick: (Int) -> Unit
    ) {
        ensureDialog()
        val lv = sList!!
        sHome!!.visibility = View.GONE
        sMsg!!.apply {
            text = message ?: ""; setTextColor(TXT)
            visibility = if (message == null) View.GONE else View.VISIBLE
        }
        lv.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        lv.adapter = object : ArrayAdapter<String>(this, 0, items) {
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val sel = pos == selected
                return tv(24f, if (sel) ACCENT else TXT, sel, Gravity.START or Gravity.CENTER_VERTICAL).apply {
                    text = (if (sel) "✔  " else "") + items[pos]
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    minimumHeight = dp(64)
                    setPadding(dp(18), dp(12), dp(18), dp(12))
                    background = cardBg(sel)
                }
            }
        }
        lv.setOnItemClickListener { v, _, i, _ -> tap(v); onPick(i) }
        if (selected > 1) lv.setSelection(selected - 2) else lv.setSelection(0)
        chrome(title, backLabel, forward, animate, onBack)
    }

    /** الصفحة الرئيسية للإعدادات: بطاقات مقسّمة إلى مجموعات */
    private fun openSettings(forward: Boolean = false) {
        ensureDialog()
        val box = sHomeBox!!
        box.removeAllViews()
        sList!!.visibility = View.GONE
        sMsg!!.visibility = View.GONE
        sHome!!.visibility = View.VISIBLE
        sHome!!.scrollTo(0, 0)

        fun section(t: String) {
            box.addView(
                tv(17f, ACCENT, true, Gravity.START or Gravity.CENTER_VERTICAL).apply {
                    text = t
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(6), dp(14), dp(6), dp(6))
                },
                LinearLayout.LayoutParams(-1, -2)
            )
        }
        fun row(label: String, value: String, action: () -> Unit) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                addView(tv(16f, MUTED, false, Gravity.START or Gravity.CENTER_VERTICAL).apply {
                    text = label; layoutDirection = View.LAYOUT_DIRECTION_RTL
                })
                addView(
                    tv(23f, TXT, true, Gravity.START or Gravity.CENTER_VERTICAL).apply {
                        text = value; layoutDirection = View.LAYOUT_DIRECTION_RTL
                    },
                    LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) }
                )
            }
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                background = cardBg(false)
                minimumHeight = dp(72)
                setPadding(dp(18), dp(10), dp(18), dp(10))
                isClickable = true
                addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                addView(tv(34f, ACCENT, true).apply { text = "‹" }, LinearLayout.LayoutParams(-2, -2))
                setOnClickListener { tap(it); action() }
            }
            box.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }

        section("الموقع والحساب")
        row("المدينة", cityName()) { pickCity() }
        row("طريقة الحساب", PrayerCalc.methodNames[s.method]) { pickMethod() }
        section("التنبيهات")
        row("التذكير قبل الصلاة", remindLabel(s.remind)) { pickRemind() }
        row("صوت التنبيه", if (s.soundOn) "مفعّل" else "معطّل") { soundPage(true) }
        if (Build.VERSION.SDK_INT >= 34 &&
            !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        ) {
            row("شاشة التنبيه الكاملة", "اضغط للتفعيل") {
                closeSettings()
                startActivity(
                    Intent(AndroidSettings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
                )
            }
        }
        section("العرض")
        row("المظهر", themeNames[s.theme]) { pickTheme() }

        chrome("الإعدادات", "إغلاق", forward, true) { closeSettings() }
    }

    private fun closeSettings() { sDlg?.dismiss() }

    private val remindValues = listOf(0, 5, 10, 15, 20, 30)
    private val themeNames = listOf("فاتح", "داكن", "حسب النظام")

    private fun remindLabel(m: Int) = if (m == 0) "بدون تذكير" else "${nf.format(m)} دقيقة قبل الصلاة"

    private fun pickMethod() {
        showPage("طريقة الحساب", PrayerCalc.methodNames, s.method, "رجوع", true,
            onBack = { openSettings(false) }) { m ->
            s.method = m
            refresh(true)
            openSettings(false)
        }
    }

    private fun pickRemind() {
        showPage("التذكير قبل الصلاة", remindValues.map { remindLabel(it) },
            remindValues.indexOf(s.remind), "رجوع", true,
            onBack = { openSettings(false) }) { pos ->
            s.remind = remindValues[pos]
            refresh(true)
            openSettings(false)
        }
    }

    private fun pickTheme() {
        showPage("المظهر", themeNames, s.theme, "رجوع", true,
            onBack = { openSettings(false) }) { pos ->
            s.theme = pos
            loadPalette()
            setContentView(buildUi())
            refresh(false)
            openSettings(false)
        }
    }

    private fun pickCity() {
        showPage("اختر المدينة", listOf("موقعي الحالي (GPS)") + PrayerCalc.cities.map { it.name },
            s.city, "رجوع", true, onBack = { openSettings(false) }) { pos ->
            s.city = pos
            if (pos == 0) requestLocation() else {
                val c = PrayerCalc.cities[pos - 1]
                s.lat = c.lat; s.lon = c.lon
                refresh(true)
            }
            openSettings(false)
        }
    }

    private fun hasAdhanFile() = resources.getIdentifier("adhan", "raw", packageName) != 0

    /** صفحة صوت التنبيه: تشغّل الصوت عند فتحها، وفيها خيار التفعيل/التعطيل */
    private fun soundPage(forward: Boolean, animate: Boolean = true) {
        val has = hasAdhanFile()
        if (s.soundOn) playPreview() else stopSound()
        val msg = when {
            !s.soundOn -> "الصوت معطّل: سيصلك وقت الصلاة إشعار صامت بدون صوت."
            has -> "يعمل الآن صوت التكبير. اختر «تعطيل الصوت» إن لم تُرده."
            else -> "ملف الأذان غير موجود داخل التطبيق، لذلك يُستخدم صوت الإشعار الافتراضي."
        }
        showPage("صوت التنبيه", listOf("تفعيل الصوت", "تعطيل الصوت"), if (s.soundOn) 0 else 1,
            "رجوع", forward, message = msg, animate = animate,
            onBack = { stopSound(); openSettings(false) }) { pos ->
            s.soundOn = pos == 0
            soundPage(true, animate = false)
        }
    }

    private var player: MediaPlayer? = null

    private fun playPreview() {
        stopSound()
        val raw = resources.getIdentifier("adhan", "raw", packageName)
        try {
            if (raw != 0) {
                val mp = MediaPlayer()
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                resources.openRawResourceFd(raw).use { mp.setDataSource(it.fileDescriptor, it.startOffset, it.length) }
                mp.setOnCompletionListener { p -> try { p.release() } catch (e: Exception) { }; if (player === p) player = null }
                mp.prepare()
                mp.start()
                player = mp
            } else {
                val r = RingtoneManager.getRingtone(this, Notifier.soundUri(this))
                if (Build.VERSION.SDK_INT >= 28) {
                    r.setAudioAttributes(
                        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
                    )
                }
                r.play()
                ringtone = r
            }
        } catch (e: Exception) { }
    }

    private fun stopSound() {
        try { ringtone?.stop() } catch (e: Exception) { }
        ringtone = null
        try { player?.stop(); player?.release() } catch (e: Exception) { }
        player = null
    }

    // ---------- البطارية (شرط إلزامي) ----------
    private var batteryTried = false

    private fun checkBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName) || s.batteryAck) {
            dlg?.dismiss(); dlg = null; return
        }
        if (dlg?.isShowing == true) return
        val msg = if (!batteryTried)
            "لكي يصلك تنبيه الصلاة في وقته تماماً، اضغط \"السماح\" ثم وافق في النافذة التالية."
        else
            "لم يتأكد التطبيق من الإذن بعد.\nإن كنت قد فعّلته فاضغط \"فعّلته بالفعل\"، وإلا اضغط \"السماح\" وحاول مرة أخرى."
        val builder = AlertDialog.Builder(this)
            .setTitle("خطوة مطلوبة")
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("السماح", null)
            .setNegativeButton("خروج") { _, _ -> finish() }
        if (batteryTried) builder.setNeutralButton("فعّلته بالفعل", null)
        val d = builder.create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).textSize = 24f
        d.getButton(AlertDialog.BUTTON_NEGATIVE).textSize = 20f
        if (batteryTried) d.getButton(AlertDialog.BUTTON_NEUTRAL).textSize = 20f
        d.findViewById<TextView>(android.R.id.message)?.textSize = 22f
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            batteryTried = true
            // نغلق النافذة قبل فتح الإعدادات، وعند العودة يُعاد الفحص بعد لحظات
            d.dismiss(); dlg = null
            startActivity(
                Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
        if (batteryTried) d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            s.batteryAck = true
            d.dismiss(); dlg = null
        }
        dlg = d
    }

    // ---------- الموقع ----------
    private fun requestLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 2)
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            try {
                val l = lm.getLastKnownLocation(p)
                val cur = best
                if (l != null && (cur == null || l.time > cur.time)) best = l
            } catch (e: SecurityException) { }
        }
        val loc = best
        if (loc == null) {
            Toast.makeText(this, "تعذّر تحديد الموقع، اختر مدينتك من الإعدادات", Toast.LENGTH_LONG).show()
        } else {
            s.lat = loc.latitude; s.lon = loc.longitude
            refresh(true)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 2 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) requestLocation()
    }
}
