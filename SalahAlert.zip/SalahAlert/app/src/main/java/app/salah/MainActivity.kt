package app.salah

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var s: Settings
    private var dlg: AlertDialog? = null
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("hh:mm a", Locale("ar"))
    private val nf = NumberFormat.getInstance(Locale("ar"))

    private val GREEN = Color.parseColor("#0B5D3B")
    private val GOLD = Color.parseColor("#FFD966")
    private val BG = Color.parseColor("#F7F3E8")
    private val DARK = Color.parseColor("#1B1B1B")

    private lateinit var cityTv: TextView
    private lateinit var nextName: TextView
    private lateinit var nextTime: TextView
    private lateinit var remainTv: TextView
    private val rowBox = arrayOfNulls<LinearLayout>(5)
    private val rowName = arrayOfNulls<TextView>(5)
    private val rowTime = arrayOfNulls<TextView>(5)

    private val tick = object : Runnable {
        override fun run() {
            refresh(false)
            handler.postDelayed(this, 30_000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: Int, stroke: Int = 0, radius: Int = 20) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(3), stroke)
    }

    private fun tv(size: Float, color: Int, bold: Boolean = true, g: Int = Gravity.CENTER) =
        TextView(this).apply {
            textSize = size
            setTextColor(color)
            gravity = g
            includeFontPadding = false
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        s = Settings(this)
        Notifier.ensureChannel(this)
        window.statusBarColor = GREEN

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }

        // بطاقة الصلاة القادمة
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = shape(GREEN, 0, 28)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        head.addView(tv(22f, Color.WHITE, false).apply { text = "الصلاة القادمة" })
        nextName = tv(50f, GOLD)
        nextTime = tv(42f, Color.WHITE)
        remainTv = tv(24f, Color.WHITE)
        cityTv = tv(18f, Color.parseColor("#CFE8DA"), false)
        for (v in listOf(nextName, nextTime, remainTv, cityTv)) head.addView(v)
        root.addView(head, LinearLayout.LayoutParams(-1, 0, 3.6f))

        // الصلوات الخمس
        for (i in 0..4) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(24), 0, dp(24), 0)
            }
            val n = tv(28f, DARK, true, Gravity.START or Gravity.CENTER_VERTICAL)
            val t = tv(28f, DARK, true, Gravity.END or Gravity.CENTER_VERTICAL)
            row.addView(n, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(t, LinearLayout.LayoutParams(-2, -2))
            rowBox[i] = row; rowName[i] = n; rowTime[i] = t
            root.addView(row, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        }

        // زر الإعدادات
        val btn = Button(this).apply {
            text = "الإعدادات"
            textSize = 26f
            isAllCaps = false
            setTypeface(null, Typeface.BOLD)
            setTextColor(GREEN)
            background = shape(Color.WHITE, GREEN, 20)
            setOnClickListener { openSettings() }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, 0, 1.1f).apply { topMargin = dp(12) })

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        refresh(true)
    }

    override fun onResume() {
        super.onResume()
        checkBattery()
        refresh(true)
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 30_000)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun cityName() =
        if (s.city == 0) "موقعي الحالي" else PrayerCalc.cities[s.city - 1].name

    private fun remainText(mins: Int): String {
        if (mins < 1) return "بعد أقل من دقيقة"
        val h = mins / 60
        val m = mins % 60
        return "بعد " + when {
            h == 0 -> "${nf.format(m)} دقيقة"
            m == 0 -> "${nf.format(h)} ساعة"
            else -> "${nf.format(h)} ساعة و ${nf.format(m)} دقيقة"
        }
    }

    private fun refresh(schedule: Boolean) {
        val now = Date()
        val times = PrayerCalc.times(s, now)
        val (ni, nt) = PrayerCalc.next(s, now.time)
        nextName.text = PrayerCalc.names[ni]
        nextTime.text = fmt.format(nt)
        remainTv.text = remainText(((nt.time - now.time + 59_999) / 60_000).toInt())
        cityTv.text = "المدينة: ${cityName()}"
        for (i in 0..4) {
            val on = i == ni
            rowName[i]!!.text = PrayerCalc.names[i]
            rowTime[i]!!.text = fmt.format(if (on) nt else times[i])
            val fg = if (on) Color.WHITE else DARK
            rowName[i]!!.setTextColor(fg)
            rowTime[i]!!.setTextColor(fg)
            rowBox[i]!!.background =
                if (on) shape(GREEN, GREEN, 18) else shape(Color.WHITE, Color.parseColor("#C9C3B0"), 18)
        }
        if (schedule) Scheduler.schedule(this)
    }

    // ---------- الإعدادات ----------
    private fun openSettings() {
        val items = listOf(
            "المدينة: ${cityName()}",
            "طريقة الحساب: ${PrayerCalc.methodNames[s.method]}",
            "العصر: ${if (s.hanafi) "حنفي" else "جمهور العلماء"}"
        )
        pick("الإعدادات", items, -1) {
            when (it) {
                0 -> pickCity()
                1 -> pick("طريقة الحساب", PrayerCalc.methodNames, s.method) { m -> s.method = m; refresh(true) }
                2 -> pick(
                    "حساب وقت العصر",
                    listOf("جمهور العلماء (الأكثر شيوعاً)", "حنفي"),
                    if (s.hanafi) 1 else 0
                ) { a -> s.hanafi = a == 1; refresh(true) }
            }
        }
    }

    private fun pickCity() {
        pick("اختر المدينة", listOf("موقعي الحالي (GPS)") + PrayerCalc.cities.map { it.name }, s.city) { pos ->
            s.city = pos
            if (pos == 0) requestLocation() else {
                val c = PrayerCalc.cities[pos - 1]
                s.lat = c.lat; s.lon = c.lon
                refresh(true)
            }
        }
    }

    private fun pick(title: String, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val titleView = tv(26f, GREEN, true, Gravity.START or Gravity.CENTER_VERTICAL).apply {
            text = title
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(18), dp(20), dp(8))
        }
        val lv = ListView(this)
        lv.layoutDirection = View.LAYOUT_DIRECTION_RTL
        lv.adapter = object : ArrayAdapter<String>(this, 0, items) {
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val sel = pos == selected
                return tv(24f, if (sel) GREEN else DARK, sel, Gravity.START or Gravity.CENTER_VERTICAL).apply {
                    text = (if (sel) "✔  " else "") + items[pos]
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(20), dp(16), dp(20), dp(16))
                }
            }
        }
        val d = AlertDialog.Builder(this)
            .setCustomTitle(titleView).setView(lv).setNegativeButton("إغلاق", null).create()
        lv.setOnItemClickListener { _, _, i, _ -> d.dismiss(); onPick(i) }
        d.show()
        d.getButton(AlertDialog.BUTTON_NEGATIVE).textSize = 22f
    }

    // ---------- البطارية (شرط إلزامي) ----------
    private fun checkBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            dlg?.dismiss(); dlg = null; return
        }
        if (dlg?.isShowing == true) return
        val d = AlertDialog.Builder(this)
            .setTitle("خطوة مطلوبة")
            .setMessage("لكي يصلك تنبيه الصلاة في وقته تماماً، اضغط \"السماح\" ثم وافق في النافذة التالية.")
            .setCancelable(false)
            .setPositiveButton("السماح", null)
            .setNegativeButton("خروج") { _, _ -> finish() }
            .create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).textSize = 24f
        d.getButton(AlertDialog.BUTTON_NEGATIVE).textSize = 20f
        d.findViewById<TextView>(android.R.id.message)?.textSize = 22f
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            startActivity(
                Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
        dlg = d
    }

    // ---------- الموقع ----------
    private fun requestLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 2)
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            try {
                val l = lm.getLastKnownLocation(p)
                val cur = best
                if (l != null && (cur == null || l.time > cur.time)) best = l
            } catch (e: SecurityException) { }
        }
        val loc = best
        if (loc == null) {
            Toast.makeText(this, "تعذّر تحديد الموقع، اختر مدينتك من الإعدادات", Toast.LENGTH_LONG).show()
        } else {
            s.lat = loc.latitude; s.lon = loc.longitude
            refresh(true)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 2 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) requestLocation()
    }
}
