package app.salah

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.os.PowerManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var s: Settings
    private lateinit var header: TextView
    private lateinit var rows: LinearLayout
    private var dlg: AlertDialog? = null
    private val fmt = SimpleDateFormat("hh:mm a", Locale("ar"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        s = Settings(this)
        Notifier.ensureChannel(this)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(24))
        }
        header = TextView(this).apply { textSize = 24f; setTypeface(null, Typeface.BOLD) }
        rows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, dp(16))
        }
        box.addView(header)
        box.addView(rows)

        box.addView(label("المدينة"))
        box.addView(spinner(listOf("موقعي الحالي (GPS)") + PrayerCalc.cities.map { it.name }, s.city) { pos ->
            s.city = pos
            if (pos == 0) requestLocation() else {
                val c = PrayerCalc.cities[pos - 1]
                s.lat = c.lat; s.lon = c.lon; refresh()
            }
        })
        box.addView(label("طريقة الحساب"))
        box.addView(spinner(PrayerCalc.methodNames, s.method) { s.method = it; refresh() })
        box.addView(CheckBox(this).apply {
            text = "العصر بالمذهب الحنفي"
            isChecked = s.hanafi
            setOnCheckedChangeListener { _, c -> s.hanafi = c; refresh() }
        })
        box.addView(Button(this).apply {
            text = "السماح بالتنبيه الدقيق"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 31) startActivity(
                    Intent(AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        })

        setContentView(ScrollView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(box)
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        refresh()
    }

    override fun onResume() {
        super.onResume()
        checkBattery()
    }

    /** شرط إلزامي: استثناء التطبيق من تحسين البطارية حتى لا تتأخر تنبيهات الصلاة. */
    private fun checkBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            dlg?.dismiss(); dlg = null; return
        }
        if (dlg?.isShowing == true) return
        val d = AlertDialog.Builder(this)
            .setTitle("خطوة مطلوبة")
            .setMessage("لكي يصلك تنبيه الصلاة في وقته تماماً، يجب السماح للتطبيق بالعمل دون قيود البطارية.")
            .setCancelable(false)
            .setPositiveButton("السماح", null)
            .setNegativeButton("خروج") { _, _ -> finish() }
            .create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            startActivity(
                Intent(AndroidSettings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
        dlg = d
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setPadding(0, dp(16), 0, dp(4)); setTypeface(null, Typeface.BOLD)
    }

    private fun spinner(items: List<String>, sel: Int, onSel: (Int) -> Unit): Spinner {
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel, false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = onSel(pos)
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return sp
    }

    private fun refresh() {
        val now = Date()
        val times = PrayerCalc.times(s, now)
        val (ni, nt) = PrayerCalc.next(s, now.time)
        header.text = "الصلاة القادمة: ${PrayerCalc.names[ni]}\n${fmt.format(nt)}"
        rows.removeAllViews()
        times.forEachIndexed { i, t ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val face = if (i == ni) Typeface.BOLD else Typeface.NORMAL
            row.addView(TextView(this).apply {
                text = PrayerCalc.names[i]; textSize = 18f; setTypeface(null, face)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply {
                text = fmt.format(t); textSize = 18f; setTypeface(null, face)
            })
            rows.addView(row)
        }
        Scheduler.schedule(this)
    }

    private fun requestLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 2)
            return
        }
        val lm = getSystemService(LocationManager::class.java)
        var best: Location? = null
        for (p in lm.getProviders(true)) {
            try {
                val l = lm.getLastKnownLocation(p)
                val cur = best
                if (l != null && (cur == null || l.time > cur.time)) best = l
            } catch (e: SecurityException) { }
        }
        val loc = best
        if (loc == null) {
            Toast.makeText(this, "تعذّر تحديد الموقع، اختر مدينتك من القائمة", Toast.LENGTH_LONG).show()
        } else {
            s.lat = loc.latitude; s.lon = loc.longitude; refresh()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 2 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) requestLocation()
    }
}
